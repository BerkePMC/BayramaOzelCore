<?php

namespace Deneme;

/*

____ _ ____ __ __ ____ 
| __ ) ___ _ __| | _____| _ \| \/ |/ ___|
| _ \ / _ \ '__| |/ / _ \ |_) | |\/| | | 
| |_) | __/ | | < __/ __/| | | | |___ 
|____/ \___|_| |_|\_\___|_| |_| |_|\____|

Code by BerkePMC
YouTuber

Facebook: facebook.com/berkee78
Messenger: m.me/berkee78
Instagram: pmcdevs (çok guzel çekilişler olacak.)
YouTube: BerkePMC
Ucret: 5 TL

*/
use pocketmine\{Player, Server};
use pocketmine\plugin\PluginBase;
use pocketmine\utils\{TexterFormat};
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\item\enchanment\Enchanment;
use pocketmine\level\Level;
use pocketmine\event\Listener;
use pocketmine\command\{Command, CommandSender, CommandExecutor, ConsoleCommandSender};
use pocketmine\entity\{Entity, Effect};
use pocketmine\event\player\{PlayerMoveEvent, PlayerJoinEvent, PlayerQuitEvent, PlayerExhaustEvent, PlayerInteractEvent, PlayerDropItemEvent};
use onebone\economyapi\EconomyAPI;

class vCore extends PluginBase implements Listener{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getServer()->getLogger()->info("Eklenti aktif.\n____ _ ____ __ __ ____ 
| __ ) ___ _ __| | _____| _ \| \/ |/ ___|
| _ \ / _ \ '__| |/ / _ \ |_) | |\/| | | 
| |_) | __/ | | < __/ __/| | | | |___ 
|____/ \___|_| |_|\_\___|_| |_| |_|\____|\n");
	}
	
	public function onCommand(CommandSender $sender, Command $kmt, string $label, array $args) : bool{
		$player = $sender->getPlayer();
		switch($kmt->getName()){
			case "sosyalmedya":
			$this->sosyalmedya($player);
			break;
            case "kurallar":
             $this->kurallar($player);
            break;
            case "ekip":
              $this->ekip($player);
            break;
            case "yenilikler":
          $this->yenilikler($player);
            break;
            case "bilgi":
     $this->kimlik($player);
            break; 
            case "fly":
			if(isset($args[0])){
				if(strtolower($args[0] == "aktif")){
					if($sender->hasPermission("fly.ozel")){
						$sender->setAllowFlight(true);
						$sender->sendMessage("§7* §bUcuyorsun!");

					}else{
						$sender->sendMessage("§7* §cBu komutu kullanabilmek için yetkilendirilmedin.");
					}
				}
				if(strtolower($args[0] == "deaktif")){
					$sender->setAllowFlight(false);
					$sender->sendMessage("§7* §cUcmuyorsun!");
				}
			}
			break;
 
		}
		return true;
	}
     public function atesyalaribaba(PlayerDropItemEvent $e){
        if($e->getPlayer()->getLevel()->getFolderName() == "dropevent"){
           if($e->getItem()->getId() == 264){ 
            $e->setCancelled(true);
             }else{
           $e->setCancelled(false);
          }
        }else{
          $e->setCancelled(false);
          }
    }
	 public function kurallar($player){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function(Player $g, array $args){
			$player = $g->getPlayer();
			$result = $args[0];
			switch($result){

			case 0:


          
                break;
			}
		});

		$form->setTitle("Kurallar Menu");
		$form->setContent("\n§e» §7Küfür, argo yasak!\n§e» §73. parti uygulamalar yasak!\n§e» §7Hile acmak yasak!\n§e» §7Hesap satisi yasak.");
		$form->addButton("§b§oAyrıl");
		$form->sendToPlayer($player);
	}
 public function sosyalmedya($player){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function(Player $g, array $args){
			$player = $g->getPlayer();
			$result = $args[0];
			switch($result){

			case 0:


          
                break;
			}
		});

		$form->setTitle("Sosyal Medya");
		$form->setContent("\n§7Facebook: §dfacebook.com/berkee78\n§7Messenger: m.me/berkee78\n§7Instagram: §dpmcdevs\n§7Twitter: §0Yok");
		$form->addButton("§c§oAyrıl");
		$form->sendToPlayer($player);
	}
 public function ekip($player){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function(Player $g, array $args){
			$player = $g->getPlayer();
			$result = $args[0];
			switch($result){

			case 0:


          
                break;
			}
		});

		$form->setTitle("Ekip");
		$form->setContent("\n§7Yonetici: §dReiSAdemFB\n§7Yonetici-Developer: §dBerkePMC\n§7Developer: §dlThecronl, EgeGianJck26\n§7Yetkili: §dMrErdem1, AlirizaPMC\n§7Gorevli: §dxTurkHarleYx\n");
		$form->addButton("§c§oAyrıl");
		$form->sendToPlayer($player);
	}
public function yenililikler($player){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function(Player $g, array $args){
			$player = $g->getPlayer();
			$result = $args[0];
			switch($result){

			case 0:


          
                break;
			}
		});

		$form->setTitle("Yenilikler");
		$form->setContent("\n§7× /ffa eklendi!\n§7× /lobi yeni lobi eklendi!\n§7× Şuanlık bu kadar:)\n");
		$form->addButton("§c§oAyrıl");
		$form->sendToPlayer($player);
	}
public function bilgi($player){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function(Player $g, array $args){
			$player = $g->getPlayer(); 
			$result = $args[0];
			switch($result){

			case 0:


          
                break;
			}
		});

		$form->setTitle("Bilgi");
		$form->setContent("\n§7× PvP savaşma türüdür. \n§7× RealyGG size bunu en güzel hali ile sağlıyor.\n§7× Sende VIP alıp, sunucunun kapanmamasına destek ol!\n§7× Lobiyi dolaş!\n");
		$form->addButton("§c§oAyrıl");
		$form->sendToPlayer($player);
	}
   public function oyuncukatil(PlayerJoinEvent $e){
 $o = $e->getPlayer();
 $ad = $o->getName();
 $o->sendMessage("§7[§1+§7] §e$ad aramıza hoş geldin!");
    $this->girmenu($o);
}
public function girmenu($player){
		$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function(Player $g, array $args){
			$player = $g->getPlayer();  
			$result = $args[0];
			switch($result){

			case 0:

	$item = ItemFactory::get(336, 3, 1);
			$item->setCustomName("§6Bilgi");
			$player->getInventory()->addItem($item);
			
			$player->sendMessage("§7> Envanterine §6Bilgi §7eşyası eklendi, gerekli yardımi ordan al.");
			
       break;
			}
		});
    $ad = $player->getName();
		$form->setTitle("Giris");
		$form->setContent("\n§7Öncelikle hoş geldin $ad! Sunucumuz PvP türündendir, gerekli yardımlar için bu uiyi kapatınca envanterine gerekli eşya verilecektir, ordan yardım al!\n");
		$form->addButton("§c§oOkey");
		$form->sendToPlayer($player);
	}
	 public function interacttb(PlayerInteractEvent $e){
        $player = $e->getPlayer();
        $block = $e->getBlock();
    
    if($player->getInventory()->getItemInHand()->getId() == 336){
			if($player->getInventory()->getItemInHand()->getCustomName() == "§6Bilgi"){
				$this->oyun($player);
        }
      }
     }
   public function oyuncuayrilamk(PlayerQuitEvent $e){
    $o = $e->getPlayer();
    $ad = $o->getName();
    $o->sendMessage("§7[§c-§7] §e$ad §baramızdan ayrıldı.");
   $e->getInventory()->clearAll();
}
}
?>
    